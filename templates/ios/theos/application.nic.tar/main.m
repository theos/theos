#import "@@CLASSPREFIX@@AppDelegate.h"

int main(int argc, char *argv[]) {
	return UIApplicationMain(argc, argv, nil, NSStringFromClass(@@CLASSPREFIX@@AppDelegate.class));
}
